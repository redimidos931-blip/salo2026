package com.shaloproducciones.streaming

import android.app.*
import android.content.Intent
import android.media.*
import android.os.IBinder
import android.util.Base64
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class StreamingService : Service() {
    companion object {
        const val ACTION_START = "com.shaloproducciones.START"
        const val ACTION_STOP = "com.shaloproducciones.STOP"
        private const val CHANNEL = "shalostream"
    }
    private val running = AtomicBoolean(false)
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var encoder: MediaCodec? = null
    private var socket: Socket? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopStreaming(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY
        }
        if (intent?.action == ACTION_START && running.compareAndSet(false, true)) {
            createChannel()
            val notification = Notification.Builder(this, CHANNEL)
                .setContentTitle("SHALOPRODUCCIONES")
                .setContentText("Transmisión de radio activa")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
            startForeground(1, notification)
            val host = intent.getStringExtra("host") ?: ""
            val port = intent.getIntExtra("port", 8000)
            val mount = intent.getStringExtra("mount") ?: "/live.aac"
            val password = intent.getStringExtra("password") ?: ""
            worker = Thread { stream(host, port, mount, password) }.also { it.start() }
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "Radio en vivo", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun stream(host: String, port: Int, mount: String, password: String) {
        try {
            val s = Socket()
            socket = s
            s.connect(InetSocketAddress(host, port), 10000)
            s.soTimeout = 5000
            val auth = Base64.encodeToString(("source:$password").toByteArray(), Base64.NO_WRAP)
            val out = BufferedOutputStream(s.getOutputStream())
            val request = "PUT $mount HTTP/1.1\r\nHost: $host\r\nAuthorization: Basic $auth\r\nContent-Type: audio/aac\r\nUser-Agent: SHALOPRODUCCIONES/1.0\r\nTransfer-Encoding: chunked\r\nConnection: keep-alive\r\n\r\n"
            out.write(request.toByteArray()); out.flush()
            // Icecast responds with HTTP 100 Continue or 200 OK depending on server configuration.
            s.soTimeout = 1000
            val input = BufferedInputStream(s.getInputStream())
            val header = ByteArray(512)
            val n = try { input.read(header) } catch (_: Exception) { -1 }
            if (n > 0) {
                val response = String(header, 0, n)
                if (!(response.contains("200") || response.contains("100"))) throw IllegalStateException("Servidor rechazó la conexión: $response")
            }

            val sampleRate = 44100
            val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            recorder = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192))
            val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 96000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 8192)
            }
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).apply {
                configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); start()
            }
            val r = recorder!!
            val codec = encoder!!
            r.startRecording()
            val pcm = ByteArray(4096)
            val info = MediaCodec.BufferInfo()
            while (running.get()) {
                val count = r.read(pcm, 0, pcm.size)
                if (count <= 0) continue
                val index = codec.dequeueInputBuffer(10000)
                if (index >= 0) {
                    val buffer = codec.getInputBuffer(index)!!
                    buffer.clear(); buffer.put(pcm, 0, count)
                    codec.queueInputBuffer(index, 0, count, System.nanoTime()/1000, 0)
                }
                var outIndex = codec.dequeueOutputBuffer(info, 10000)
                while (outIndex >= 0) {
                    val data = codec.getOutputBuffer(outIndex)
                    if (data != null && info.size > 0) {
                        data.position(info.offset); data.limit(info.offset + info.size)
                        val aac = ByteArray(info.size); data.get(aac)
                        val packet = adts(aac, sampleRate, 1)
                        val chunkHeader = (Integer.toHexString(packet.size) + "\r\n").toByteArray()
                        out.write(chunkHeader); out.write(packet); out.write("\r\n".toByteArray()); out.flush()
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    outIndex = codec.dequeueOutputBuffer(info, 0)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("ShaloStreaming", "Error de transmisión", e)
        } finally {
            running.set(false)
            releaseAudio()
            try { socket?.close() } catch (_: Exception) {}
            socket = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun adts(aac: ByteArray, sampleRate: Int, channels: Int): ByteArray {
        val rates = intArrayOf(96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350)
        val freq = rates.indexOf(sampleRate).let { if (it < 0) 4 else it }
        val length = aac.size + 7
        val h = byteArrayOf(
            0xFF.toByte(), 0xF1.toByte(),
            (((2 - 1) shl 6) or (freq shl 2) or (channels shr 2)).toByte(),
            (((channels and 3) shl 6) or (length shr 11)).toByte(),
            ((length and 0x7FF) shr 3).toByte(),
            ((((length and 7) shl 5) or 0x1F)).toByte(),
            0xFC.toByte()
        )
        return h + aac
    }

    private fun stopStreaming() {
        running.set(false)
        try { recorder?.stop() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
    }
    private fun releaseAudio() {
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { encoder?.stop() } catch (_: Exception) {}
        try { encoder?.release() } catch (_: Exception) {}
        encoder = null
    }
    override fun onDestroy() { stopStreaming(); super.onDestroy() }
}
