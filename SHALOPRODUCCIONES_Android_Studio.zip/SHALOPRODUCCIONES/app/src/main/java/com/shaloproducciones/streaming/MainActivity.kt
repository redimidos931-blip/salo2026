package com.shaloproducciones.streaming

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import android.view.ViewGroup

class MainActivity : Activity() {
    private lateinit var host: EditText
    private lateinit var port: EditText
    private lateinit var mount: EditText
    private lateinit var password: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 42, 36, 24)
            setBackgroundColor(0xFF101B35.toInt())
        }
        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 15f; setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 12, 0, 4)
        }
        fun field(hintText: String, value: String = "", input: Int = 1): EditText {
            return EditText(this).apply {
                hint = hintText; setText(value); textSize = 16f
                inputType = input
                setSingleLine(true)
                setTextColor(0xFFFFFFFF.toInt())
                setHintTextColor(0xFFB8C5DA.toInt())
                setPadding(18, 10, 18, 10)
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xFF263858.toInt()); cornerRadius = 14f
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 5 }
            }
        }
        root.addView(TextView(this).apply {
            text = "SHALOPRODUCCIONES"
            textSize = 25f; setTextColor(0xFF63D6FF.toInt()); gravity = 17
            setPadding(0, 8, 0, 4); typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "TRANSMISIÓN DE RADIO EN VIVO"
            textSize = 13f; setTextColor(-1); gravity = 17; setPadding(0, 0, 0, 18)
        })
        root.addView(label("Servidor Icecast"))
        host = field("Ej.: radio.midominio.com"); root.addView(host)
        root.addView(label("Puerto"))
        port = field("8000", "8000", 2); root.addView(port)
        root.addView(label("Punto de montaje"))
        mount = field("Ej.: /shaloproducciones.mp3", "/live.aac"); root.addView(mount)
        root.addView(label("Contraseña de fuente"))
        password = field("Contraseña Icecast", "", 129); root.addView(password)
        status = TextView(this).apply {
            text = "Estado: listo para configurar"
            textSize = 14f; setTextColor(0xFFB8C5DA.toInt()); gravity = 17
            setPadding(0, 20, 0, 16)
        }
        root.addView(status)
        val start = Button(this).apply { text = "●  INICIAR TRANSMISIÓN" }
        root.addView(start)
        val stop = Button(this).apply { text = "■  DETENER TRANSMISIÓN" }
        root.addView(stop)
        root.addView(TextView(this).apply {
            text = "Necesitás los datos de un servidor Icecast. La app transmite el micrófono del teléfono."
            textSize = 12f; setTextColor(0xFFB8C5DA.toInt()); setPadding(4, 18, 4, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })

        start.setOnClickListener {
            if (host.text.isBlank() || password.text.isBlank() || mount.text.isBlank()) {
                status.text = "Completá servidor, punto de montaje y contraseña."
                return@setOnClickListener
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
                status.text = "Permití el uso del micrófono y volvé a iniciar."
                return@setOnClickListener
            }
            val i = Intent(this, StreamingService::class.java).apply {
                action = StreamingService.ACTION_START
                putExtra("host", host.text.toString().trim())
                putExtra("port", port.text.toString().toIntOrNull() ?: 8000)
                putExtra("mount", mount.text.toString().trim().let { if (it.startsWith("/")) it else "/$it" })
                putExtra("password", password.text.toString())
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            status.text = "Estado: iniciando conexión…"
        }
        stop.setOnClickListener {
            startService(Intent(this, StreamingService::class.java).setAction(StreamingService.ACTION_STOP))
            status.text = "Estado: transmisión detenida"
        }
    }
}
