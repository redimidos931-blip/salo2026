# SHALOPRODUCCIONES — Android Streaming

Proyecto inicial Android Studio (Kotlin) para transmitir el micrófono del teléfono a un servidor **Icecast** mediante HTTP PUT, codificando AAC-LC a 44,1 kHz / 96 kbps.

## Requisitos
- Android Studio reciente y JDK 17.
- Un servidor Icecast accesible desde Internet.
- Datos de fuente Icecast: host, puerto, mountpoint y contraseña de source.
- Permiso de micrófono.

## Abrir y compilar
1. Descomprimí el ZIP.
2. En Android Studio elegí **Open** y seleccioná la carpeta `SHALOPRODUCCIONES`.
3. Esperá la sincronización de Gradle.
4. Conectá un teléfono Android, habilitá depuración USB y presioná Run.
5. Para generar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Configuración de transmisión
- Servidor: nombre DNS o IP del servidor Icecast (sin `http://`).
- Puerto: normalmente 8000.
- Punto de montaje: por ejemplo `/live.aac`.
- Contraseña: contraseña de fuente (source password), no la contraseña de administración.

## Importante
Este es un **prototipo inicial**. El servidor Icecast debe aceptar fuentes AAC/ADTS por HTTP PUT y transferencia chunked. La compatibilidad depende de la configuración y versión del servidor. Antes de emitir al público, probá la conexión con el administrador del servidor y verificá el mountpoint desde un reproductor externo.

El prototipo no incluye todavía reproducción de retorno, mezcla de música, automatización, ecualizador ni reconexión automática. Para publicar en Google Play y para uso estable en producción se recomienda probar permisos/servicio en varias versiones Android, manejar estados de conexión en pantalla y validar el formato exacto admitido por el servidor.
